<?
session_start();
mysql_connect ("localhost", "root", "123456");
mysql_select_db("restaurante");


//hora

$hora = new DateTime();
$hora->setTimezone(new DateTimeZone('America/Mexico_City'));
$fecha=date($hora->format('Y/m/d H:i:s'));
//echo $fecha;


//$fecha=date('Y/m/d H:i:s');

//hora
//echo $fecha;

$idpersona=$_SESSION['persona'];
$idmesa=$_SESSION['mesa'];

//echo "persona" .$idpersona;
mysql_query("update mesa set mFecha='$fecha' where mId='$idmesa'");


mysql_query("INSERT INTO venta (vCantidadProducto, vFecha, vIdpersona,vMesa) VALUES ('20','$fecha','$idpersona','$idmesa')");

$rs = mysql_query("SELECT MAX(vId) AS id FROM venta");
if ($row = mysql_fetch_row($rs)) {
$idultimo = trim($row[0]);
}
//echo $idultimo;

foreach ($_SESSION["arr"] as $valor){
//echo 'id: '. $valor['id'].'<br/>';
mysql_query("INSERT INTO venta_detalle(vId,vd_idProducto, vd_Cantidad, vd_Costo) VALUES ('$idultimo','".$valor['id']."','".$valor['cantidad']."','".$valor['costo']."')");
	
	//mysql_query("UPDATE venta SET vCantidadProducto = '20', vFecha= '16/09/1986' ,vIdusuario='1',vIdTiket='5'");


}
 echo "<div id='10668'>Pedido Realizado</div>"; 
 echo "<script languaje='javascript'>alert('pedido registrado. ')</script>";
 session_destroy();
 
?>