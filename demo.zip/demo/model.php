<?php
function getAllPosts($familia)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT idProducto, pNombre, pDescripcion, pPrecio, pFamilia, pImg, pThumb FROM productos where pFamilia='.$familia.' and idCarta=0', $link);
 
  // Filling up the array
  $cproductos = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cproductos[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cproductos;
}
function getAllPersonas($familia)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT pId, pNombres, pApellidos, pFechNac, pSexo, pTelCell,pImg FROM persona', $link);
 
  // Filling up the array
  $cproductos = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cproductos[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cproductos;
}
function getAllVentas($familia)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT vId, vCantidadProducto, vFecha, vIdusuario, vIdTiket, vMesa FROM venta', $link);
 
  // Filling up the array
  $cventas = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cventas[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cventas;
}

function getAllMesas($familia)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT mId, mNumero, mFamilia, mEstado, mImg, mFecha FROM mesa', $link);
 
  // Filling up the array
  $cproductos = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cproductos[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cproductos;
}
function getAllCategorias($cat)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
  
  // Performing SQL query
  $result = mysql_query(' SELECT fId, fNombre,fThumb FROM familia where fCategoria= '.$cat.'', $link);
 
  // Filling up the array
  $cproductos = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cproductos[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cproductos;
}
function getAllItems()
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT id, pNombre, pDescripcion, pPrecio, pFamilia, pImg, pThumb FROM productos ', $link);
 
  // Filling up the array
  $cproductos = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cproductos[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cproductos;
}

function getDetallePedidos($idx)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT v.vId,v.vCantidadProducto, v.vFecha,v.vIdTiket, v.vMesa, vd.vd_Cantidad, vd.vd_Costo, p.pNombre,p.pPrecio ,per.pNombres, per.pApellidos from venta v inner JOIN venta_detalle vd on vd.vId=v.vId INNER JOIN productos p on vd.vd_idProducto = p.id INNER JOIN persona per on v.vIdpersona = per.pId and vd.vId='.$idx.'', $link);
 
  // Filling up the array
  $cDetallePedidos = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cDetallePedidos[] = $row;
  }
 
  // Closing connection
  mysql_close($link);
 
  return $cDetallePedidos;
}
function getEstadoMesas($idx)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT mNumero, mEstado , mFecha FROM mesa WHERE mEstado = "1" ', $link);
 
  // Filling up the array
  $cEstadoMesas = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cEstadoMesas[] = $row;
  }
  // Closing connection
  mysql_close($link);
  return $cEstadoMesas;
}


function getProductoBases($idx)
{	
  // Connecting, selecting database
  $link = mysql_connect('localhost', 'root', '123456');
  mysql_select_db('restaurante', $link);
 
  // Performing SQL query
  $result = mysql_query('SELECT pNombre,pPrecio FROM productobase ', $link);
 
  // Filling up the array
  $cProductoBases = array();
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
     $cProductoBases[] = $row;
  }
  // Closing connection
  mysql_close($link);
  return $cProductoBases;
}



?>