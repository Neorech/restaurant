<style type="text/css">
.info, .exito, .alerta, .error {
font-family:Arial, Helvetica, sans-serif;
font-size:13px;
border: 1px solid;
margin: 10px 8px;
padding:15px 10px 15px 50px;
background-repeat: no-repeat;
background-position: 10px center;
position:relative;
width: 150px;
float:left;
}
.info {
color: #00529B;
background-color: #BDE5F8;
background-image: url('http://webintenta.com/uploads/Files/Images/v8/Mensajes/info.png');
}
.exito {
color: #4F8A10;
background-color: #DFF2BF;
background-image:url('http://webintenta.com/uploads/Files/Images/v8/Mensajes/exito.png');
}
.alerta {
color: #9F6000;
background-color: #FEEFB3;
background-image: url('http://webintenta.com/uploads/Files/Images/v8/Mensajes/alerta.png');
}
.error {
color: #D8000C;
background-color: #FFBABA;
background-image: url('http://webintenta.com/uploads/Files/Images/v8/Mensajes/error.png');
}
</style>

<?
require_once('model.php');
$idx =$_GET[id];
$getEstadoMesas = getEstadoMesas($idx);
//echo "holas";
//Este contenido va a cambiar :D</div>
$hora = new DateTime();
$hora->setTimezone(new DateTimeZone('America/Mexico_City'));
$fecha_b=date($hora->format('Y/m/d H:i:s'));
//echo $fecha_b;
 function minutos_transcurridos($fecha_i,$fecha_f)
{
$minutos = (strtotime($fecha_i)-strtotime($fecha_f))/60;
$minutos = abs($minutos); $minutos = floor($minutos);
return $minutos;
}

 foreach($getEstadoMesas as $getEstadoMesa):
 
  $fecha_a= $getEstadoMesa['mFecha'];
  
  $tiempo =minutos_transcurridos($fecha_a,$fecha_b); 
 	if ($tiempo<=3) 
 	{
		$clase='exito';
	}
	else
	{
		$clase='error';
	}
 	//echo "<div id='789'>";
	echo "<div class=".$clase.">";
	echo "Tiempo: ".$tiempo.'<p>'; 
	echo $getEstadoMesa['mFecha'].'<p><h2>Mesa: '.$getEstadoMesa['mNumero']. '</h2><p>' ;
	echo '<div class='.$getEstadoMesa['mNumero'].'>realizado</div>';
	echo '</div>';
 	endforeach; 
?>